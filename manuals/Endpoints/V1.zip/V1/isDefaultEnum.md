##### Is Default Enum
	{
		default:'ok',
		notDefault:'not'
	}


