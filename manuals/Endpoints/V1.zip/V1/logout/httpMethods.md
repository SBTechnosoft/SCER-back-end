##### logout
            
##### `DELETE /logout/user/{userId}`

+ Error Message

			{
				... Error Message
			} 
+ Response

			{
				... status(200:ok)
			}

**NOTES:** delete the active_session user