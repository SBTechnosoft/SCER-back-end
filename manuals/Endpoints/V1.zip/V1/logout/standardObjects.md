##### Standard Bank Object

            {
                "bankId": int,
                "bankName":String
            }
            
##### Standard Bank Persistable Object
			{
            	 "bankName":String
            }

