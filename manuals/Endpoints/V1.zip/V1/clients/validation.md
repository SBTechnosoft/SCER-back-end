##### Product Validation Rules

- stateName
	- `required`
- stateAbb 
	- `required`

