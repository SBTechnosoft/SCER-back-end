##### Standard State Object

            {
                "stateAbb": char,
                "stateName": string,
				"isDisplay": Enum,
				"stateCode": int,
				"createdAt" timestamp,
				"updatedAt": datetime
                
            }

##### Standard state Persistable Object

 			{
            	"stateName": string,
				"isDisplay": Enum,
				"stateCode": int,
				"createdAt" timestamp,
				"updatedAt": datetime,
				"deletedAt":datetime	
            }
			
#####  Is Display Enum
			{
				... Is Display Enum
			}
