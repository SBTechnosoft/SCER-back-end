##### Document Validation Rules

+ document
	
	+ `format` - the documents must be in one of the formats defined by `Standard Document Format Enum`