##### Standard Document Object

            {
                "documentId":int,
                "documentName": string,
                "documentUrl": string,
                "documentSize": int,
                "documentFormat": Enum
		  }

##### Standard Document Persistable Object

            {
                "document": file
			}


##### Document Format Enum
			{
				documentFormat: `jpeg | jpg | gif | png | pdf`
			}
            
