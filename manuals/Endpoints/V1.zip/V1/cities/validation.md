##### Product Validation Rules

- city_name
	`between:1,35|regex:/^[a-zA-Z &-]+$/`

