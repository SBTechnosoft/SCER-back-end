##### Standard Ledger Group Object

            {
                "ledgerGroupId": int,
                "ledgerGroupName":String,
				"alias":String,
                "underWhat":String
				"natureOfGroup":String
				"affectedGroupProfit":Enum
            }
            
##### Standard Ledger Group Persistable Object
			{
            	"ledgerGroupName":String,
				"alias":String,
                "underWhat":String,
				"natureOfGroup":String,
				"affectedGroupProfit":Enum
            }

##### Affected Group Profit Enum
			{
				groupProfitAffected:'yes',
				groupProfitNotAffected:'no'	
			}

