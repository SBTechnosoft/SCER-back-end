##### Gets LedgerGrps           
            
##### `GET /accounting/ledger-groups/{ledgerGrpId}/`
+ Header 
	- Authentication Token

+ Error Message

			{
				... Error Message
			}    
+ Response

			{
				... Standard Ledger Group Object
			}

**NOTES:** Provide Ledger Group details based on provided Ledger Number

##### `GET /accounting/ledger-groups/`
+ Header 
	- Authentication Token

+ Error Message

			{
				... Error Message
			}    
+ Response

			{
				... Standard Ledger Group Object
			}

**NOTES:** List all the ledger groups 
