##### Is Display Enum
	{
		display:'yes',
		notDisplay:'no'
	}


