##### Quotation Validation Rules

- pending
