##### Standard Profession Object

            {
                "professionId": int,
                "professionName":String,
                "description":text,
                "professionParentId":int,
				"createdAt":TimeStamp,
				"updatedAt":datetime,
			}
            
##### Standard Profession Persistable Object
			{
            	"professionId": int,
                "professionName":String,
                "description":text,
                "professionParentId":int
            }