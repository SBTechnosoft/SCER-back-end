##### Template Validation Rules

--pending
