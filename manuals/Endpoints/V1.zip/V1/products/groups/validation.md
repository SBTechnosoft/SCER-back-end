##### product-groups Validation Rules

- product_group_name
	`between:1,35|regex:/^[a-zA-Z0-9 &,\/_`#().\'-]+$/`
