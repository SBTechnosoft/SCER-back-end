$.getScript('app/vendor/ng-table/ng-table.min.js');
$.getScript('app/vendor/ng-table/ng-table.min.css');
$.getScript('app/vendor/angularjs-toaster/toaster.js');
$.getScript('app/vendor/angularjs-toaster/toaster.css');