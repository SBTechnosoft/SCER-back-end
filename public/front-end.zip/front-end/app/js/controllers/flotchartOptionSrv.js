

/**=========================================================
 * Module: FlotChartOptionsServices.js
 * Define here the common options for all types of charts
 * and access theme from your controller
 =========================================================*/
App.service('flotOptions', ['$rootScope', function($rootScope) {
  'use strict';
  var flotOptions = {};

  flotOptions['default'] = {
    grid: {
      hoverable: true,
      clickable: true,
      borderWidth: 0,
      color: '#8394a9'
    },
    tooltip: true,
    tooltipOpts: {
      content: '%x : %y'
    },
    xaxis: {
      tickColor: '#f1f2f3',
      mode: 'categories'
    },
    yaxis: {
      tickColor: '#f1f2f3',
      position: ($rootScope.app.layout.isRTL ? 'right' : 'left')
    },
    legend: {
      backgroundColor: 'rgba(0,0,0,0)'
    },
    shadowSize: 0
  };

  flotOptions['bar'] = angular.extend({}, flotOptions['default'], {
    series: {
      bars: {
        align: 'center',
        lineWidth: 0,
        show: true,
        barWidth: 0.6,
        fill: 1
      }
    }
  });

  flotOptions['bar-stacked'] = angular.extend({}, flotOptions['default'], {
    series: {
      bars: {
        align: 'center',
        lineWidth: 0,
        show: true,
        barWidth: 0.6,
        fill: 1,
        stacked: true
      }
    }
  });

  flotOptions['line'] = angular.extend({}, flotOptions['default'], {
    series: {
      lines: {
        show: true,
        fill: 0.01
      },
      points: {
        show: true,
        radius: 4
      }
    }
  });

  flotOptions['spline'] = angular.extend({}, flotOptions['default'], {
    series: {
      lines: {
        show: false
      },
      splines: {
        show: true,
        tension: 0.4,
        lineWidth: 1,
        fill: 1
      },
    }
  });

  flotOptions['area'] = angular.extend({}, flotOptions['default'], {
    series: {
      lines: {
        show: true,
        fill: 1
      }
    }
  });

  flotOptions['pie'] = {
    series: {
      pie: {
        show: true,
        innerRadius: 0,
        label: {
          show: true,
          radius: 0.8,
          formatter: function (label, series) {
            return '<div class="flot-pie-label">' +
            //label + ' : ' +
            Math.round(series.percent) +
            '%</div>';
          },
          background: {
            opacity: 0.8,
            color: '#222'
          }
        }
      }
    }
  };

  flotOptions['donut'] = {
    series: {
      pie: {
        show: true,
        innerRadius: 0.5 // donut shape
      }
    }
  };



  return flotOptions;
}]);